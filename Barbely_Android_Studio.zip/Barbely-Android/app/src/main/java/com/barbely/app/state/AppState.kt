package com.barbely.app.state

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.barbely.app.data.AppException
import com.barbely.app.data.Appointment
import com.barbely.app.data.AppointmentStatus
import com.barbely.app.data.BarbelyDb
import com.barbely.app.data.Barber
import com.barbely.app.data.Repository
import com.barbely.app.data.Schedule
import com.barbely.app.data.ScheduleDraft
import com.barbely.app.data.Service
import com.barbely.app.data.TimeSlot
import com.barbely.app.data.User
import com.barbely.app.data.UserRole
import com.barbely.app.logic.getAvailableSlots
import com.barbely.app.logic.nowMinutes
import com.barbely.app.logic.timeToMinutes
import com.barbely.app.logic.todayISO
import com.barbely.app.logic.weekdayOf

/**
 * Estado global de la app (reemplaza a AuthContext + los stores con listeners de Firestore).
 * Después de cada escritura se vuelve a leer la base local, así las pantallas se actualizan solas.
 */
class AppState(context: Context) {

    private val appContext: Context = context.applicationContext
    private val repo = Repository(BarbelyDb(appContext))
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var user by mutableStateOf<User?>(null)
        private set
    var services by mutableStateOf<List<Service>>(emptyList())
        private set
    var barbers by mutableStateOf<List<Barber>>(emptyList())
        private set
    var schedules by mutableStateOf<List<Schedule>>(emptyList())
        private set

    /** Citas que el usuario actual puede ver (gerente: todas, barbero/cliente: las suyas). */
    var appointments by mutableStateOf<List<Appointment>>(emptyList())
        private set

    /** Sube cada vez que cambian los datos; sirve para recalcular la disponibilidad en pantalla. */
    var dataVersion by mutableIntStateOf(0)
        private set

    init {
        restoreSession()
    }

    // ------------------------------------------------------------------
    // Sesión
    // ------------------------------------------------------------------

    private fun restoreSession() {
        val uid = prefs.getString(KEY_UID, null) ?: return
        val saved = try {
            repo.getUser(uid)
        } catch (e: Exception) {
            null
        }
        if (saved != null && saved.activo) {
            user = saved
            refresh()
        } else {
            prefs.edit().remove(KEY_UID).apply()
        }
    }

    private fun startSession(newUser: User) {
        user = newUser
        prefs.edit().putString(KEY_UID, newUser.uid).apply()
        refresh()
    }

    private fun endSession() {
        user = null
        prefs.edit().remove(KEY_UID).apply()
        services = emptyList()
        barbers = emptyList()
        schedules = emptyList()
        appointments = emptyList()
        dataVersion += 1
    }

    /** Vuelve a leer todo desde la base de datos. */
    fun refresh() {
        services = repo.services()
        barbers = repo.barbers()
        schedules = repo.schedules()
        appointments = user?.let { repo.appointmentsFor(it) } ?: emptyList()
        dataVersion += 1
    }

    // ------------------------------------------------------------------
    // Autenticación
    // ------------------------------------------------------------------

    fun signIn(email: String, password: String): User {
        val signedIn = repo.authenticate(email, password)
        startSession(signedIn)
        return signedIn
    }

    /** El registro público siempre crea un cliente; barberos y gerente se administran aparte. */
    fun signUp(nombre: String, email: String, password: String): User {
        val created = repo.createUser(nombre, email, password, UserRole.CLIENTE)
        startSession(created)
        return created
    }

    fun resetPassword(email: String, newPassword: String) {
        repo.resetPassword(email, newPassword)
    }

    fun updateProfile(nombre: String, telefono: String?) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        repo.updateProfile(current.uid, nombre, telefono)
        user = current.copy(nombre = nombre, telefono = telefono)
    }

    fun deleteAccount() {
        val current = user ?: return
        repo.deleteUser(current.uid)
        endSession()
    }

    fun signOut() {
        endSession()
    }

    // ------------------------------------------------------------------
    // Consultas para las pantallas
    // ------------------------------------------------------------------

    fun activeServices(): List<Service> = services.filter { it.activo }

    fun activeBarbers(): List<Barber> = barbers.filter { it.activo }

    fun service(id: String?): Service? = services.firstOrNull { it.id == id }

    fun barber(id: String?): Barber? = barbers.firstOrNull { it.id == id }

    fun schedulesFor(barberoId: String): List<Schedule> = schedules.filter { it.barberoId == barberoId }

    /** Barbero que corresponde al usuario que inició sesión. */
    fun currentBarber(): Barber {
        val me = user
        val byId = barbers.firstOrNull { it.id == me?.uid }
        if (byId != null) return byId
        val byEmail = barbers.firstOrNull { me != null && it.email.equals(me.email, ignoreCase = true) }
        if (byEmail != null) return byEmail
        return Barber(
            id = me?.uid ?: "",
            nombre = me?.nombre ?: "Barbero",
            descripcion = null,
            especialidad = "",
            calificacionPromedio = null,
            activo = true,
            createdAt = "",
            email = me?.email,
        )
    }

    private fun resolve(a: Appointment): Appointment =
        a.copy(barbero = barber(a.barberoId), servicio = service(a.servicioId))

    private fun newestFirst(list: List<Appointment>): List<Appointment> =
        list.sortedByDescending { it.fecha + it.horaInicio }

    fun appointment(id: String?): Appointment? =
        appointments.firstOrNull { it.id == id }?.let { resolve(it) }

    fun clientAppointments(clienteId: String): List<Appointment> =
        newestFirst(appointments.filter { it.clienteId == clienteId }).map { resolve(it) }

    /** La cita activa más cercana en el tiempo (pendiente o confirmada) que todavía no termina. */
    fun nextClientAppointment(clienteId: String): Appointment? {
        val today = todayISO()
        val now = nowMinutes()
        return appointments
            .filter {
                it.clienteId == clienteId &&
                    (it.estado == AppointmentStatus.PENDIENTE || it.estado == AppointmentStatus.CONFIRMADA) &&
                    (it.fecha > today || (it.fecha == today && timeToMinutes(it.horaFin) > now))
            }
            .minByOrNull { it.fecha + it.horaInicio }
            ?.let { resolve(it) }
    }

    fun barberAppointments(barberoId: String): List<Appointment> =
        newestFirst(appointments.filter { it.barberoId == barberoId }).map { resolve(it) }

    /** Citas de un barbero en un día puntual (sin canceladas), ordenadas por hora — para la Agenda. */
    fun barberAppointmentsByDate(barberoId: String, fecha: String): List<Appointment> =
        appointments
            .filter {
                it.barberoId == barberoId && it.fecha == fecha && it.estado != AppointmentStatus.CANCELADA
            }
            .sortedBy { it.horaInicio }
            .map { resolve(it) }

    fun allAppointments(): List<Appointment> = newestFirst(appointments).map { resolve(it) }

    /**
     * Franjas del barbero para un día. Considera las citas de todos los clientes
     * y, si la fecha es hoy, deshabilita las horas que ya pasaron.
     */
    fun slotsFor(barberId: String?, fecha: String?, duracionMinutos: Int): List<TimeSlot> {
        if (barberId == null || fecha == null || duracionMinutos <= 0) return emptyList()
        val earliest = if (fecha == todayISO()) nowMinutes() + 1 else 0
        return getAvailableSlots(
            weekday = weekdayOf(fecha),
            schedules = schedulesFor(barberId),
            busy = repo.busyRanges(barberId, fecha),
            duracionMinutos = duracionMinutos,
            earliestStart = earliest,
        )
    }

    // ------------------------------------------------------------------
    // Citas
    // ------------------------------------------------------------------

    fun createAppointment(barberoId: String, servicioId: String, fecha: String, horaInicio: String): Appointment {
        val current = user ?: throw AppException("Debes iniciar sesión para reservar.")
        val chosen = service(servicioId) ?: throw AppException("El servicio ya no está disponible.")
        val created = repo.createAppointment(
            cliente = current,
            barberoId = barberoId,
            servicioId = servicioId,
            fecha = fecha,
            horaInicio = horaInicio,
            duracionMinutos = chosen.duracion,
            precio = chosen.precio,
        )
        refresh()
        return created
    }

    /**
     * Mismas reglas que tenía Firestore: el gerente puede todo, el barbero cambia el estado de sus citas
     * y el cliente solo puede cancelar las suyas.
     */
    fun updateAppointmentStatus(id: String, estado: AppointmentStatus) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        val cita = appointments.firstOrNull { it.id == id } ?: throw AppException("Cita no encontrada.")
        val allowed = when (current.rol) {
            UserRole.GERENTE -> true
            UserRole.BARBERO -> cita.barberoId == current.uid
            UserRole.CLIENTE -> cita.clienteId == current.uid && estado == AppointmentStatus.CANCELADA
        }
        if (!allowed) throw AppException("No tienes permiso para modificar esta cita.")
        repo.updateAppointmentStatus(id, estado)
        refresh()
    }

    // ------------------------------------------------------------------
    // Administración (gerente)
    // ------------------------------------------------------------------

    private fun requireManager() {
        if (user?.rol != UserRole.GERENTE) throw AppException("Solo el gerente puede hacer esto.")
    }

    fun saveService(
        id: String?,
        nombre: String,
        descripcion: String?,
        precio: Double,
        duracion: Int,
        activo: Boolean,
    ) {
        requireManager()
        repo.saveService(id, nombre, descripcion, precio, duracion, activo)
        refresh()
    }

    fun setServiceActive(id: String, activo: Boolean) {
        requireManager()
        repo.setServiceActive(id, activo)
        refresh()
    }

    fun saveBarber(
        id: String?,
        nombre: String,
        especialidad: String,
        descripcion: String?,
        activo: Boolean,
        email: String,
        initialPassword: String?,
    ) {
        requireManager()
        repo.saveBarber(id, nombre, especialidad, descripcion, activo, email, initialPassword)
        refresh()
    }

    fun setBarberActive(id: String, activo: Boolean) {
        requireManager()
        repo.setBarberActive(id, activo)
        refresh()
    }

    // ------------------------------------------------------------------
    // Barbero
    // ------------------------------------------------------------------

    fun updateBarberProfile(id: String, especialidad: String, descripcion: String?) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        if (current.rol != UserRole.GERENTE && current.uid != id) {
            throw AppException("No tienes permiso para editar este perfil.")
        }
        repo.updateBarberProfile(id, especialidad, descripcion)
        refresh()
    }

    fun saveSchedules(barberoId: String, drafts: List<ScheduleDraft>) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        if (current.rol != UserRole.GERENTE && current.uid != barberoId) {
            throw AppException("No tienes permiso para editar este horario.")
        }
        repo.replaceSchedules(barberoId, drafts)
        refresh()
    }

    private companion object {
        const val PREFS_NAME = "barbely_session"
        const val KEY_UID = "uid"
    }
}
