package com.barbely.app.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.Instant

/**
 * Base de datos local SQLite. Reemplaza a Cloud Firestore + Firebase Authentication.
 * Las tablas equivalen a las colecciones originales: usuarios, barberos, servicios, horarios, citas.
 */
class BarbelyDb(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        for (statement in SCHEMA) db.execSQL(statement)
        Seed.insertDemoData(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Todavía no hay migraciones: la versión 1 es la inicial.
    }

    companion object {
        const val DB_NAME = "barbely.db"
        const val DB_VERSION = 1

        val SCHEMA: List<String> = listOf(
            """
            CREATE TABLE usuarios (
                uid TEXT PRIMARY KEY,
                nombre TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                telefono TEXT,
                rol TEXT NOT NULL,
                activo INTEGER NOT NULL DEFAULT 1,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """.trimIndent(),
            """
            CREATE TABLE barberos (
                id TEXT PRIMARY KEY,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                especialidad TEXT NOT NULL,
                calificacion REAL,
                activo INTEGER NOT NULL DEFAULT 1,
                email TEXT,
                created_at TEXT NOT NULL
            )
            """.trimIndent(),
            """
            CREATE TABLE servicios (
                id TEXT PRIMARY KEY,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                precio REAL NOT NULL,
                duracion INTEGER NOT NULL,
                activo INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            )
            """.trimIndent(),
            """
            CREATE TABLE horarios (
                id TEXT PRIMARY KEY,
                barbero_id TEXT NOT NULL,
                dia_semana INTEGER NOT NULL,
                hora_inicio TEXT NOT NULL,
                hora_fin TEXT NOT NULL,
                activo INTEGER NOT NULL DEFAULT 1
            )
            """.trimIndent(),
            """
            CREATE TABLE citas (
                id TEXT PRIMARY KEY,
                cliente_id TEXT NOT NULL,
                cliente_nombre TEXT,
                cliente_telefono TEXT,
                barbero_id TEXT NOT NULL,
                servicio_id TEXT NOT NULL,
                fecha TEXT NOT NULL,
                hora_inicio TEXT NOT NULL,
                hora_fin TEXT NOT NULL,
                precio REAL NOT NULL,
                duracion INTEGER NOT NULL,
                estado TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """.trimIndent(),
            "CREATE INDEX idx_horarios_barbero ON horarios (barbero_id)",
            "CREATE INDEX idx_citas_barbero_fecha ON citas (barbero_id, fecha)",
            "CREATE INDEX idx_citas_cliente ON citas (cliente_id)",
        )
    }
}

/**
 * Datos de demostración que se crean la primera vez que se abre la app.
 * (En la versión con Firebase la cuenta de gerente y los datos se cargaban a mano en la consola.)
 */
object Seed {
    const val MANAGER_EMAIL = "gerente@barbely.com"
    const val MANAGER_PASSWORD = "gerente123"
    const val BARBER_PASSWORD = "barbero123"
    const val CLIENT_EMAIL = "cliente@barbely.com"
    const val CLIENT_PASSWORD = "cliente123"

    private data class SeedBarber(
        val nombre: String,
        val email: String,
        val especialidad: String,
        val descripcion: String,
        val calificacion: Double,
    )

    private data class SeedService(
        val nombre: String,
        val descripcion: String,
        val precio: Double,
        val duracion: Int,
    )

    fun insertDemoData(db: SQLiteDatabase) {
        val now = Instant.now().toString()

        // Gerente
        db.insertUserRow(
            uid = newId(),
            nombre = "Gerente Barbely",
            email = MANAGER_EMAIL,
            telefono = null,
            rol = UserRole.GERENTE,
            activo = true,
            password = MANAGER_PASSWORD,
            createdAt = now,
        )

        // Cliente de demostración
        db.insertUserRow(
            uid = newId(),
            nombre = "Cliente Demo",
            email = CLIENT_EMAIL,
            telefono = null,
            rol = UserRole.CLIENTE,
            activo = true,
            password = CLIENT_PASSWORD,
            createdAt = now,
        )

        // Barberos (cada uno con su usuario de acceso y su horario de lunes a sábado)
        val barbers = listOf(
            SeedBarber(
                "Carlos Mendoza", "carlos@barbely.com", "Fade y barba clásica",
                "Más de 8 años de experiencia en degradados y barba.", 4.9,
            ),
            SeedBarber(
                "Luis Hernández", "luis@barbely.com", "Cortes modernos y diseños",
                "Especialista en estilos actuales y diseños a navaja.", 4.8,
            ),
            SeedBarber(
                "Miguel Rivas", "miguel@barbely.com", "Barba y perfilado",
                "Perfilado preciso y cuidado de barba con toalla caliente.", 4.7,
            ),
        )
        for (b in barbers) {
            val id = newId()
            db.insertUserRow(id, b.nombre, b.email, null, UserRole.BARBERO, true, BARBER_PASSWORD, now)
            db.insertBarberRow(id, b.nombre, b.descripcion, b.especialidad, b.calificacion, true, b.email, now)
            for (day in 1..6) {
                db.insertScheduleRow(newId(), id, day, "09:00", "13:00", true)
                db.insertScheduleRow(newId(), id, day, "14:00", "18:00", true)
            }
        }

        // Servicios
        val services = listOf(
            SeedService("Corte clásico", "Corte a tijera o máquina con acabado limpio.", 8.0, 30),
            SeedService("Corte + barba", "Corte completo y perfilado de barba con toalla caliente.", 12.0, 60),
            SeedService("Barba", "Perfilado y arreglo de barba.", 6.0, 30),
            SeedService("Fade con diseño", "Degradado con diseño personalizado a navaja.", 10.0, 60),
            SeedService("Corte infantil", "Corte para niños hasta 12 años.", 6.0, 30),
        )
        for (s in services) {
            db.insertServiceRow(newId(), s.nombre, s.descripcion, s.precio, s.duracion, true, now)
        }
    }
}
