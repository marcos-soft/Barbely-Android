package com.barbely.app.data

/**
 * BARBELY — Modelos de datos (equivalentes a src/types/index.ts).
 * Las tablas SQLite reflejan las colecciones originales:
 * usuarios, barberos, servicios, horarios y citas.
 */

enum class UserRole(val db: String) {
    CLIENTE("cliente"),
    BARBERO("barbero"),
    GERENTE("gerente");

    companion object {
        fun from(value: String?): UserRole = entries.firstOrNull { it.db == value } ?: CLIENTE
    }
}

enum class AppointmentStatus(val db: String, val label: String) {
    PENDIENTE("pendiente", "Pendiente"),
    CONFIRMADA("confirmada", "Confirmada"),
    COMPLETADA("completada", "Completada"),
    CANCELADA("cancelada", "Cancelada");

    companion object {
        fun from(value: String?): AppointmentStatus =
            entries.firstOrNull { it.db == value } ?: PENDIENTE
    }
}

data class User(
    val uid: String,
    val nombre: String,
    val email: String,
    val telefono: String?,
    val rol: UserRole,
    val activo: Boolean,
    val createdAt: String,
)

data class Barber(
    val id: String,
    val nombre: String,
    val descripcion: String?,
    val especialidad: String,
    val calificacionPromedio: Double?,
    val activo: Boolean,
    val createdAt: String,
    val email: String?,
)

data class Service(
    val id: String,
    val nombre: String,
    val descripcion: String?,
    val precio: Double,
    val duracion: Int, // minutos
    val activo: Boolean,
    val createdAt: String,
)

/** diaSemana: 0 = domingo, 1 = lunes ... 6 = sábado (igual que Date#getDay() en JS). */
data class Schedule(
    val id: String,
    val barberoId: String,
    val diaSemana: Int,
    val horaInicio: String, // "09:00"
    val horaFin: String, // "18:00"
    val activo: Boolean,
)

data class Appointment(
    val id: String,
    val clienteId: String,
    val barberoId: String,
    val servicioId: String,
    val fecha: String, // "2026-09-25"
    val horaInicio: String, // "10:30"
    val horaFin: String, // "11:00"
    val precio: Double,
    val duracion: Int,
    val estado: AppointmentStatus,
    val createdAt: String,
    val clienteNombre: String?,
    val clienteTelefono: String?,
    // Datos resueltos para mostrar en la interfaz (no se guardan en la tabla de citas)
    val barbero: Barber? = null,
    val servicio: Service? = null,
)

data class TimeSlot(
    val horaInicio: String,
    val horaFin: String,
    val disponible: Boolean,
)

/** Error con mensaje listo para mostrar al usuario. */
class AppException(message: String) : Exception(message)
