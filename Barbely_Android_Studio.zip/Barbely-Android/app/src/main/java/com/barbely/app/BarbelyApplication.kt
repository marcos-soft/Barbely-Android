package com.barbely.app

import android.app.Application
import com.barbely.app.state.AppState
import com.barbely.app.ui.nav.Navigator
import com.barbely.app.ui.nav.Route

/**
 * El estado vive en la Application para que sobreviva a que Android recree la pantalla
 * (cambio de tema, de tamaño de letra, etc.) sin perder la sesión ni la navegación.
 */
class BarbelyApplication : Application() {

    lateinit var appState: AppState
        private set
    lateinit var navigator: Navigator
        private set

    override fun onCreate() {
        super.onCreate()
        appState = AppState(this)
        navigator = Navigator(if (appState.user != null) Route.Home else Route.Welcome)
    }
}
