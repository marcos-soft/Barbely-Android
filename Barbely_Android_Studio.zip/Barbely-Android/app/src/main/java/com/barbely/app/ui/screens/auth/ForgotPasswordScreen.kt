package com.barbely.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.barbely.app.data.AppException
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BIcon
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

/**
 * Sin servidor de correo (se eliminó Firebase) no se puede mandar un enlace de recuperación,
 * así que la contraseña se restablece aquí mismo: correo + nueva contraseña.
 */
@Composable
fun ForgotPasswordScreen() {
    val app = LocalApp.current
    val nav = LocalNav.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }

    fun submit() {
        formError = null
        if (email.trim().isEmpty()) {
            formError = "Escribe tu correo electrónico."
            return
        }
        if (password.length < 6) {
            formError = "La contraseña debe tener al menos 6 caracteres."
            return
        }
        if (password != confirmPassword) {
            formError = "Las contraseñas no coinciden."
            return
        }
        try {
            app.resetPassword(email.trim(), password)
            done = true
        } catch (e: AppException) {
            formError = e.message
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        BHeader(title = "Recuperar contraseña")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 24.dp),
        ) {
            if (done) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 12.dp)
                            .size(64.dp)
                            .background(BColors.successBg, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        BIcon(BIcons.Checkmark, 28.dp, BColors.success)
                    }
                    BText("Contraseña actualizada", BType.h1, BColors.textPrimary, textAlign = TextAlign.Center)
                    BText(
                        text = "Ya puedes iniciar sesión con tu nueva contraseña.",
                        style = BType.body,
                        color = BColors.textSecondary,
                        modifier = Modifier.padding(bottom = 12.dp),
                        textAlign = TextAlign.Center,
                    )
                    BButton(
                        label = "Volver a inicio de sesión",
                        onClick = { nav.pop() },
                        variant = ButtonVariant.Secondary,
                    )
                }
            } else {
                BText("¿Olvidaste tu contraseña?", BType.h1, BColors.textPrimary, Modifier.padding(bottom = 8.dp))
                BText(
                    text = "Escribe tu correo y elige una nueva contraseña para tu cuenta.",
                    style = BType.body,
                    color = BColors.textSecondary,
                    modifier = Modifier.padding(bottom = 24.dp),
                )
                BInput(
                    value = email,
                    onValueChange = { email = it },
                    label = "Correo electrónico",
                    placeholder = "tucorreo@ejemplo.com",
                    leftIcon = BIcons.Mail,
                    keyboardType = KeyboardType.Email,
                    capitalization = KeyboardCapitalization.None,
                )
                BInput(
                    value = password,
                    onValueChange = { password = it },
                    label = "Nueva contraseña",
                    placeholder = "Mínimo 6 caracteres",
                    secure = true,
                    leftIcon = BIcons.LockClosed,
                    keyboardType = KeyboardType.Password,
                    capitalization = KeyboardCapitalization.None,
                )
                BInput(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = "Confirmar nueva contraseña",
                    placeholder = "Repite la contraseña",
                    secure = true,
                    leftIcon = BIcons.LockClosed,
                    keyboardType = KeyboardType.Password,
                    capitalization = KeyboardCapitalization.None,
                )
                val message = formError
                if (message != null) {
                    BText(message, BType.caption, BColors.danger, Modifier.padding(bottom = 8.dp))
                }
                BButton(label = "Cambiar contraseña", onClick = { submit() })
            }
        }
    }
}
