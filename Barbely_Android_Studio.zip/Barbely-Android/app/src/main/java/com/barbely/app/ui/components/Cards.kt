package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.barbely.app.data.Appointment
import com.barbely.app.data.Barber
import com.barbely.app.data.Service
import com.barbely.app.logic.decimal1
import com.barbely.app.logic.formatFechaCorta
import com.barbely.app.logic.money
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

/** Tarjeta de cita (components/AppointmentCard.tsx). [subtitle] es el barbero o el cliente según la vista. */
@Composable
fun AppointmentCard(appointment: Appointment, onClick: () -> Unit, subtitle: String? = null) {
    PressableCard(onClick = onClick, modifier = Modifier.fillMaxWidth(), elevation = 4.dp) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                BText(
                    text = appointment.servicio?.nombre ?: "Servicio",
                    style = BType.bodyMedium,
                    color = BColors.textPrimary,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                StatusBadge(appointment.estado)
            }
            if (subtitle != null) {
                BText(subtitle, BType.caption, BColors.textSecondary)
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    BIcon(BIcons.Calendar, 14.dp, BColors.textMuted)
                    BText(formatFechaCorta(appointment.fecha), BType.caption, BColors.textMuted)
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    BIcon(BIcons.Time, 14.dp, BColors.textMuted)
                    BText(appointment.horaInicio, BType.caption, BColors.textMuted)
                }
                Spacer(modifier = Modifier.weight(1f))
                BText(money(appointment.precio), BType.captionMedium, BColors.gold)
            }
        }
    }
}

/** Tarjeta de barbero (components/BarberCard.tsx). */
@Composable
fun BarberCard(barber: Barber, onClick: () -> Unit, selected: Boolean = false) {
    val rating = barber.calificacionPromedio
    PressableCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        color = if (selected) BColors.surfaceElevated else BColors.surface,
        pressedColor = BColors.surfaceElevated,
        borderColor = if (selected) BColors.gold else BColors.borderSubtle,
        borderWidth = 1.5.dp,
        elevation = 4.dp,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Avatar(name = barber.nombre, size = 48)
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                BText(
                    text = barber.nombre,
                    style = BType.bodyMedium,
                    color = BColors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                BText(
                    text = barber.especialidad,
                    style = BType.caption,
                    color = BColors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (!barber.activo) {
                BText(
                    text = "Inactivo",
                    style = BType.caption,
                    color = BColors.danger,
                    modifier = Modifier
                        .background(BColors.dangerBg, RoundedCornerShape(BRadius.pill))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                )
            } else if (rating != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    BIcon(BIcons.Star, 14.dp, BColors.gold)
                    BText(decimal1(rating), BType.captionMedium, BColors.textPrimary)
                }
            }
        }
    }
}

/** Tarjeta de servicio (components/ServiceCard.tsx). */
@Composable
fun ServiceCard(service: Service, onClick: () -> Unit) {
    PressableCard(onClick = onClick, modifier = Modifier.fillMaxWidth(), elevation = 4.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                BText(
                    text = service.nombre,
                    style = BType.h3,
                    color = BColors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val description = service.descripcion
                if (!description.isNullOrEmpty()) {
                    BText(
                        text = description,
                        style = BType.caption,
                        color = BColors.textSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        BIcon(BIcons.Time, 14.dp, BColors.textMuted)
                        BText("${service.duracion} min", BType.caption, BColors.textMuted)
                    }
                    if (service.activo) {
                        BText(money(service.precio), BType.bodyMedium, BColors.gold)
                    } else {
                        BText(
                            text = "Inactivo",
                            style = BType.caption,
                            color = BColors.danger,
                            modifier = Modifier
                                .background(BColors.dangerBg, RoundedCornerShape(BRadius.pill))
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                        )
                    }
                }
            }
            BIcon(BIcons.ChevronForward, 20.dp, BColors.textMuted)
        }
    }
}
