package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

/** Título grande de las pantallas con pestañas. */
@Composable
fun TabTitle(title: String, bottomPadding: Dp = 16.dp) {
    BText(
        text = title,
        style = BType.h1,
        color = BColors.textPrimary,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = bottomPadding),
    )
}

/** Pie de pantalla con borde superior (donde va el botón principal). */
@Composable
fun ScreenFooter(content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BColors.borderSubtle))
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp), content = content)
    }
}

/** Tarjeta con filas de información (detalle de cita, resumen de reserva). */
@Composable
fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    BCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            content = content,
        )
    }
}

/** Fila "ícono + etiqueta ........ valor". Si recibe [onClick] el valor se muestra como enlace. */
@Composable
fun InfoRow(
    icon: Int,
    label: String,
    value: String,
    emphasis: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            BIcon(icon, 18.dp, BColors.textSecondary)
            BText(label, BType.body, BColors.textSecondary)
        }
        val valueColor = if (emphasis || onClick != null) BColors.gold else BColors.textPrimary
        val valueStyle = if (emphasis) BType.h3 else BType.bodyMedium
        var valueModifier = Modifier.weight(1f, fill = false).padding(start = 12.dp)
        if (onClick != null) valueModifier = valueModifier.tappable(onClick = onClick)
        BText(value, valueStyle, valueColor, valueModifier, textAlign = TextAlign.End)
    }
}

/** Tarjeta con un número grande (paneles del barbero y del gerente). */
@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    BCard(modifier = modifier) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            BText(value, BType.h2, BColors.gold)
            BText(label, BType.caption, BColors.textSecondary, textAlign = TextAlign.Center)
        }
    }
}

/** Chip de filtro en forma de cápsula. */
@Composable
fun FilterChip(label: String, active: Boolean, onClick: () -> Unit, verticalPadding: Dp = 8.dp) {
    val shape = RoundedCornerShape(BRadius.pill)
    BText(
        text = label,
        style = BType.captionMedium,
        color = if (active) BColors.onGold else BColors.textSecondary,
        modifier = Modifier
            .background(if (active) BColors.gold else BColors.surface, shape)
            .border(1.dp, if (active) BColors.gold else BColors.borderSubtle, shape)
            .tappable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = verticalPadding),
    )
}

/** Interruptor "Activo / Inactivo" de los formularios del gerente. */
@Composable
fun ActiveToggleRow(active: Boolean, onToggle: () -> Unit) {
    val shape = RoundedCornerShape(BRadius.lg)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp)
            .background(BColors.surface, shape)
            .border(1.dp, BColors.borderSubtle, shape)
            .tappable(onClick = onToggle)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            BIcon(
                icon = if (active) BIcons.CheckmarkCircle else BIcons.CloseCircle,
                size = 20.dp,
                tint = if (active) BColors.success else BColors.textMuted,
            )
            BText(if (active) "Activo" else "Inactivo", BType.bodyMedium, BColors.textPrimary)
        }
        BText("Toca para cambiar", BType.caption, BColors.textMuted)
    }
}
