package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.barbely.app.data.AppException
import com.barbely.app.data.Schedule
import com.barbely.app.data.ScheduleDraft
import com.barbely.app.data.newId
import com.barbely.app.logic.timeToMinutes
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType
import kotlinx.coroutines.delay

private val DAY_LABELS = mapOf(
    0 to "Domingo", 1 to "Lunes", 2 to "Martes", 3 to "Miércoles",
    4 to "Jueves", 5 to "Viernes", 6 to "Sábado",
)
private val WEEKDAYS = listOf(1, 2, 3, 4, 5, 6, 0)
private val TIME_FORMAT = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")

private data class EditableBlock(
    val key: String,
    val id: String?,
    val diaSemana: Int,
    val horaInicio: String,
    val horaFin: String,
)

private fun Schedule.toEditable() = EditableBlock(
    key = id,
    id = id,
    diaSemana = diaSemana,
    horaInicio = horaInicio,
    horaFin = horaFin,
)

/**
 * Editor del horario semanal de UN barbero (components/ScheduleEditor.tsx).
 * Si el barbero puede cambiar en la misma pantalla (selector del gerente), llámalo dentro de
 * `key(barberoId) { ... }` para que reinicie su estado al cambiar de barbero.
 */
@Composable
fun ScheduleEditor(barberoId: String) {
    val app = LocalApp.current
    val blocks = remember {
        val list = mutableStateListOf<EditableBlock>()
        list.addAll(app.schedulesFor(barberoId).map { it.toEditable() })
        list
    }
    var error by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(saved) {
        if (saved) {
            delay(1800)
            saved = false
        }
    }

    fun updateBlock(key: String, start: String?, end: String?) {
        val index = blocks.indexOfFirst { it.key == key }
        if (index < 0) return
        val current = blocks[index]
        blocks[index] = current.copy(
            horaInicio = start ?: current.horaInicio,
            horaFin = end ?: current.horaFin,
        )
    }

    fun addBlock(day: Int) {
        blocks.add(
            EditableBlock(
                key = "new-" + newId(),
                id = null,
                diaSemana = day,
                horaInicio = "09:00",
                horaFin = "13:00",
            ),
        )
    }

    fun validate(): String? {
        val badFormat = blocks.any {
            !TIME_FORMAT.matches(it.horaInicio) ||
                !TIME_FORMAT.matches(it.horaFin) ||
                timeToMinutes(it.horaFin) <= timeToMinutes(it.horaInicio)
        }
        if (badFormat) return "Revisa el formato (HH:MM) y que la hora de fin sea posterior al inicio."
        for (day in WEEKDAYS) {
            val ordered = blocks.filter { it.diaSemana == day }.sortedBy { timeToMinutes(it.horaInicio) }
            for (i in 1 until ordered.size) {
                if (timeToMinutes(ordered[i].horaInicio) < timeToMinutes(ordered[i - 1].horaFin)) {
                    return "Hay horarios que se empalman el mismo día (${DAY_LABELS[day]})."
                }
            }
        }
        return null
    }

    fun save() {
        val problem = validate()
        if (problem != null) {
            error = problem
            return
        }
        error = null
        try {
            app.saveSchedules(
                barberoId,
                blocks.map { ScheduleDraft(it.id, it.diaSemana, it.horaInicio, it.horaFin) },
            )
            // Recarga con los ids reales para que un segundo guardado no duplique horarios.
            blocks.clear()
            blocks.addAll(app.schedulesFor(barberoId).map { it.toEditable() })
            saved = true
        } catch (e: AppException) {
            error = e.message
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            BText(
                text = "Un día sin horarios queda cerrado para agendar. Los cambios se reflejan de inmediato " +
                    "en lo que ven los clientes al reservar.",
                style = BType.caption,
                color = BColors.textSecondary,
            )
            for (day in WEEKDAYS) {
                val dayBlocks = blocks.filter { it.diaSemana == day }
                val cardShape = RoundedCornerShape(BRadius.lg)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BColors.surface, cardShape)
                        .border(1.dp, BColors.borderSubtle, cardShape)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        BText(DAY_LABELS[day] ?: "", BType.h3, BColors.textPrimary)
                        Row(
                            modifier = Modifier.tappable { addBlock(day) },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            BIcon(BIcons.Add, 16.dp, BColors.gold)
                            BText("Horario", BType.captionMedium, BColors.gold)
                        }
                    }
                    if (dayBlocks.isEmpty()) {
                        BText("Cerrado", BType.caption, BColors.textMuted)
                    } else {
                        for (block in dayBlocks) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                TimeField(
                                    value = block.horaInicio,
                                    onValueChange = { updateBlock(block.key, it, null) },
                                    placeholder = "09:00",
                                    modifier = Modifier.weight(1f),
                                )
                                BText("–", BType.body, BColors.textMuted)
                                TimeField(
                                    value = block.horaFin,
                                    onValueChange = { updateBlock(block.key, null, it) },
                                    placeholder = "13:00",
                                    modifier = Modifier.weight(1f),
                                )
                                Box(
                                    modifier = Modifier
                                        .tappable { blocks.removeAll { it.key == block.key } }
                                        .padding(4.dp),
                                ) {
                                    BIcon(BIcons.Trash, 16.dp, BColors.danger)
                                }
                            }
                        }
                    }
                }
            }
            val message = error
            if (message != null) BText(message, BType.caption, BColors.danger)
        }
        ScreenFooter {
            BButton(label = if (saved) "Guardado ✓" else "Guardar cambios", onClick = { save() })
        }
    }
}

@Composable
private fun TimeField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(BRadius.sm)
    Box(
        modifier = modifier
            .background(BColors.backgroundElevated, shape)
            .border(1.dp, BColors.border, shape)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (value.isEmpty()) {
            BText(placeholder, BType.bodyMedium, BColors.textMuted, textAlign = TextAlign.Center)
        }
        BasicTextField(
            value = value,
            onValueChange = { text -> if (text.length <= 5) onValueChange(text) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = BType.bodyMedium.copy(color = BColors.textPrimary, textAlign = TextAlign.Center),
            cursorBrush = SolidColor(BColors.gold),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Done,
            ),
        )
    }
}
