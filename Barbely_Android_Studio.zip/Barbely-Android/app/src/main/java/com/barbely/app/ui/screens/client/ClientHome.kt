package com.barbely.app.ui.screens.client

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.components.AppointmentCard
import com.barbely.app.ui.components.Avatar
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BModal
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.BottomTabBar
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.components.EmptyState
import com.barbely.app.ui.components.ServiceCard
import com.barbely.app.ui.components.TabItem
import com.barbely.app.ui.components.TabTitle
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType
import kotlinx.coroutines.delay

/** Pantalla principal del cliente: 4 pestañas (Inicio, Servicios, Mis citas, Perfil). */
@Composable
fun ClientHome() {
    val app = LocalApp.current
    val nav = LocalNav.current
    var deleteVisible by remember { mutableStateOf(false) }
    val tabs = remember {
        listOf(
            TabItem("Inicio", BIcons.Home),
            TabItem("Servicios", BIcons.Cut),
            TabItem("Mis citas", BIcons.Calendar),
            TabItem("Perfil", BIcons.Person),
        )
    }

    Box(modifier = Modifier.fillMaxSize().background(BColors.background)) {
        Column(modifier = Modifier.fillMaxSize().imePadding()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when (nav.homeTab) {
                    0 -> ClientHomeTab()
                    1 -> ClientServicesTab()
                    2 -> ClientAppointmentsTab()
                    else -> ClientProfileTab(onDeleteRequest = { deleteVisible = true })
                }
            }
            BottomTabBar(items = tabs, selected = nav.homeTab, onSelect = { nav.homeTab = it })
        }

        BModal(visible = deleteVisible, onClose = { deleteVisible = false }, title = "Eliminar cuenta") {
            BText(
                text = "Esta acción es permanente. Se eliminarán tu perfil y tu historial de citas.",
                style = BType.body,
                color = BColors.textSecondary,
                modifier = Modifier.padding(bottom = 20.dp),
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BButton(
                    label = "Cancelar",
                    onClick = { deleteVisible = false },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Ghost,
                    fullWidth = false,
                )
                BButton(
                    label = "Eliminar",
                    onClick = {
                        deleteVisible = false
                        app.deleteAccount()
                        nav.resetTo(Route.Welcome)
                    },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Danger,
                    fullWidth = false,
                )
            }
        }
    }
}

@Composable
private fun ClientHomeTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val user = app.user
    val firstName = (user?.nombre ?: "Cliente").trim().split(" ").first()
    val next = if (user != null) app.nextClientAppointment(user.uid) else null
    val featured = app.activeServices().take(3)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            BText("Hola, $firstName", BType.h1, BColors.textPrimary)
            BText("¿Listo para tu próximo corte?", BType.body, BColors.textSecondary)
        }

        BButton(
            label = "Reservar una cita",
            onClick = { nav.homeTab = 1 },
            icon = BIcons.Calendar,
        )

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            BText("Tu próxima cita", BType.h3, BColors.textPrimary)
            if (next != null) {
                AppointmentCard(
                    appointment = next,
                    subtitle = next.barbero?.nombre,
                    onClick = { nav.push(Route.ClientAppointment(next.id)) },
                )
            } else {
                EmptyState(
                    icon = BIcons.Calendar,
                    title = "Aún no tienes citas",
                    description = "Reserva tu primer corte en un par de toques.",
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            BText("Servicios populares", BType.h3, BColors.textPrimary)
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                for (service in featured) {
                    ServiceCard(service = service, onClick = { nav.push(Route.ServiceDetail(service.id)) })
                }
            }
        }
    }
}

@Composable
private fun ClientServicesTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val services = app.activeServices()

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TabTitle("Servicios")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (services.isEmpty()) {
                item {
                    EmptyState(
                        icon = BIcons.Cut,
                        title = "No hay servicios disponibles",
                        description = "Vuelve más tarde.",
                    )
                }
            } else {
                items(services, key = { it.id }) { service ->
                    ServiceCard(service = service, onClick = { nav.push(Route.ServiceDetail(service.id)) })
                }
            }
        }
    }
}

@Composable
private fun ClientAppointmentsTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val user = app.user
    val appointments = if (user != null) app.clientAppointments(user.uid) else emptyList()

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TabTitle("Mis citas")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (appointments.isEmpty()) {
                item {
                    EmptyState(
                        icon = BIcons.Calendar,
                        title = "Aún no tienes citas",
                        description = "Cuando reserves un corte, aparecerá aquí.",
                        actionLabel = "Ver servicios",
                        onAction = { nav.homeTab = 1 },
                    )
                }
            } else {
                items(appointments, key = { it.id }) { appointment ->
                    AppointmentCard(
                        appointment = appointment,
                        subtitle = appointment.barbero?.nombre,
                        onClick = { nav.push(Route.ClientAppointment(appointment.id)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun ClientProfileTab(onDeleteRequest: () -> Unit) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val user = app.user ?: return
    var nombre by remember { mutableStateOf(user.nombre) }
    var telefono by remember { mutableStateOf(user.telefono ?: "") }
    var saved by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(saved) {
        if (saved) {
            delay(1800)
            saved = false
        }
    }

    fun save() {
        if (nombre.trim().isEmpty()) {
            nameError = "El nombre no puede estar vacío."
            return
        }
        nameError = null
        app.updateProfile(nombre.trim(), telefono.trim().ifEmpty { null })
        saved = true
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 56.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Avatar(name = user.nombre, size = 72)
            BText(user.nombre, BType.h2, BColors.textPrimary, Modifier.padding(top = 12.dp))
            BText(user.email, BType.body, BColors.textSecondary)
        }

        Column {
            BInput(
                value = nombre,
                onValueChange = { nombre = it },
                label = "Nombre completo",
                leftIcon = BIcons.Person,
                error = nameError,
            )
            BInput(
                value = telefono,
                onValueChange = { telefono = it },
                label = "Teléfono",
                placeholder = "Opcional",
                leftIcon = BIcons.Call,
                keyboardType = KeyboardType.Phone,
            )
            BButton(
                label = if (saved) "Guardado ✓" else "Guardar cambios",
                onClick = { save() },
                variant = ButtonVariant.Secondary,
            )
        }

        Column(
            modifier = Modifier.padding(top = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BButton(
                label = "Cerrar sesión",
                onClick = {
                    app.signOut()
                    nav.resetTo(Route.Welcome)
                },
                variant = ButtonVariant.Ghost,
            )
            BButton(label = "Eliminar mi cuenta", onClick = onDeleteRequest, variant = ButtonVariant.Danger)
        }
    }
}
