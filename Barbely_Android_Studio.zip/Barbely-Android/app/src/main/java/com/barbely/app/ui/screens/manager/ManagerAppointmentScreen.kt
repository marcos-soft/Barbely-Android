package com.barbely.app.ui.screens.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.barbely.app.logic.formatFechaLarga
import com.barbely.app.logic.money
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ErrorState
import com.barbely.app.ui.components.InfoCard
import com.barbely.app.ui.components.InfoRow
import com.barbely.app.ui.components.StatusBadge
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

/** Vista de solo lectura de una cita para el gerente. */
@Composable
fun ManagerAppointmentScreen(appointmentId: String) {
    val app = LocalApp.current
    val appointment = app.appointment(appointmentId)

    if (appointment == null) {
        Column(modifier = Modifier.fillMaxSize().background(BColors.background)) {
            BHeader(title = "Cita")
            ErrorState(title = "Cita no encontrada")
        }
        return
    }

    val phone = appointment.clienteTelefono
    Column(modifier = Modifier.fillMaxSize().background(BColors.background).navigationBarsPadding()) {
        BHeader(title = "Detalle de la cita")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                BText(
                    text = appointment.servicio?.nombre ?: "Servicio",
                    style = BType.h1,
                    color = BColors.textPrimary,
                    modifier = Modifier.weight(1f).padding(end = 12.dp),
                )
                StatusBadge(appointment.estado)
            }
            InfoCard {
                InfoRow(BIcons.Cut, "Barbero", appointment.barbero?.nombre ?: "—")
                InfoRow(BIcons.Person, "Cliente", appointment.clienteNombre ?: "—")
                if (!phone.isNullOrEmpty()) {
                    InfoRow(BIcons.Call, "Teléfono", phone)
                }
                InfoRow(BIcons.Calendar, "Fecha", formatFechaLarga(appointment.fecha))
                InfoRow(BIcons.Time, "Hora", "${appointment.horaInicio} – ${appointment.horaFin}")
                InfoRow(BIcons.Pricetag, "Precio", money(appointment.precio))
            }
            BText(
                text = "Esta vista es de solo lectura. Confirmar, completar o cancelar la cita lo hace el " +
                    "barbero asignado desde su propio panel.",
                style = BType.caption,
                color = BColors.textMuted,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
        }
    }
}
