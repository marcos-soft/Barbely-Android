package com.barbely.app.ui.screens.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.barbely.app.data.AppException
import com.barbely.app.ui.components.ActiveToggleRow
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ScreenFooter
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

/** Alta y edición de barberos (id == null crea uno nuevo). */
@Composable
fun BarberFormScreen(barberId: String?) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val existing = if (barberId != null) app.barber(barberId) else null
    val isEditing = existing != null

    var nombre by remember { mutableStateOf(existing?.nombre ?: "") }
    var especialidad by remember { mutableStateOf(existing?.especialidad ?: "") }
    var descripcion by remember { mutableStateOf(existing?.descripcion ?: "") }
    var activo by remember { mutableStateOf(existing?.activo ?: true) }
    var email by remember { mutableStateOf(existing?.email ?: "") }
    var initialPassword by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun submit() {
        if (nombre.trim().isEmpty() || especialidad.trim().isEmpty()) {
            error = "Nombre y especialidad son obligatorios."
            return
        }
        if (!isEditing && (email.trim().isEmpty() || initialPassword.length < 6)) {
            error = "Para crear un barbero necesitas un correo y una contraseña de al menos 6 caracteres."
            return
        }
        error = null
        try {
            app.saveBarber(
                id = existing?.id,
                nombre = nombre.trim(),
                especialidad = especialidad.trim(),
                descripcion = descripcion.trim().ifEmpty { null },
                activo = activo,
                email = email.trim(),
                initialPassword = if (isEditing) null else initialPassword,
            )
            nav.pop()
        } catch (e: AppException) {
            error = e.message
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        BHeader(title = if (isEditing) "Editar barbero" else "Nuevo barbero")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
        ) {
            BInput(
                value = nombre,
                onValueChange = { nombre = it },
                label = "Nombre completo",
                leftIcon = BIcons.Person,
                capitalization = KeyboardCapitalization.Words,
            )
            BInput(
                value = especialidad,
                onValueChange = { especialidad = it },
                label = "Especialidad",
                leftIcon = BIcons.Cut,
            )
            BInput(
                value = email,
                onValueChange = { email = it },
                label = "Correo de acceso",
                leftIcon = BIcons.Mail,
                keyboardType = KeyboardType.Email,
                capitalization = KeyboardCapitalization.None,
            )
            if (!isEditing) {
                BInput(
                    value = initialPassword,
                    onValueChange = { initialPassword = it },
                    label = "Contraseña inicial",
                    leftIcon = BIcons.LockClosed,
                    secure = true,
                    keyboardType = KeyboardType.Password,
                    capitalization = KeyboardCapitalization.None,
                )
            }
            BInput(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = "Descripción",
                placeholder = "Opcional",
                leftIcon = BIcons.DocumentText,
                multiline = true,
            )
            ActiveToggleRow(active = activo, onToggle = { activo = !activo })
            val message = error
            if (message != null) {
                BText(message, BType.caption, BColors.danger, Modifier.padding(top = 12.dp))
            }
        }
        ScreenFooter {
            BButton(
                label = if (isEditing) "Guardar cambios" else "Crear barbero",
                onClick = { submit() },
            )
        }
    }
}

private fun plainNumber(value: Double): String =
    if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()

/** Alta y edición de servicios (id == null crea uno nuevo). */
@Composable
fun ServiceFormScreen(serviceId: String?) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val existing = if (serviceId != null) app.service(serviceId) else null
    val isEditing = existing != null

    var nombre by remember { mutableStateOf(existing?.nombre ?: "") }
    var descripcion by remember { mutableStateOf(existing?.descripcion ?: "") }
    var precio by remember { mutableStateOf(if (existing != null) plainNumber(existing.precio) else "") }
    var duracion by remember { mutableStateOf(if (existing != null) existing.duracion.toString() else "") }
    var activo by remember { mutableStateOf(existing?.activo ?: true) }
    var error by remember { mutableStateOf<String?>(null) }

    fun submit() {
        val precioNum = precio.trim().replace(',', '.').toDoubleOrNull()
        val duracionNum = duracion.trim().toIntOrNull()
        if (nombre.trim().isEmpty()) {
            error = "El nombre es obligatorio."
            return
        }
        if (precioNum == null || !precioNum.isFinite() || precioNum <= 0.0) {
            error = "El precio debe ser un número mayor a cero."
            return
        }
        if (duracionNum == null || duracionNum <= 0) {
            error = "La duración debe ser un número entero de minutos mayor a cero."
            return
        }
        error = null
        try {
            app.saveService(
                id = existing?.id,
                nombre = nombre.trim(),
                descripcion = descripcion.trim().ifEmpty { null },
                precio = precioNum,
                duracion = duracionNum,
                activo = activo,
            )
            nav.pop()
        } catch (e: AppException) {
            error = e.message
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        BHeader(title = if (isEditing) "Editar servicio" else "Nuevo servicio")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
        ) {
            BInput(
                value = nombre,
                onValueChange = { nombre = it },
                label = "Nombre",
                leftIcon = BIcons.Cut,
            )
            BInput(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = "Descripción",
                placeholder = "Opcional",
                leftIcon = BIcons.DocumentText,
                multiline = true,
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    BInput(
                        value = precio,
                        onValueChange = { precio = it },
                        label = "Precio (USD)",
                        placeholder = "8.00",
                        leftIcon = BIcons.Pricetag,
                        keyboardType = KeyboardType.Decimal,
                    )
                }
                Box(modifier = Modifier.weight(1f)) {
                    BInput(
                        value = duracion,
                        onValueChange = { duracion = it },
                        label = "Duración (min)",
                        placeholder = "30",
                        leftIcon = BIcons.Time,
                        keyboardType = KeyboardType.Number,
                    )
                }
            }
            ActiveToggleRow(active = activo, onToggle = { activo = !activo })
            val message = error
            if (message != null) {
                BText(message, BType.caption, BColors.danger, Modifier.padding(top = 12.dp))
            }
        }
        ScreenFooter {
            BButton(
                label = if (isEditing) "Guardar cambios" else "Crear servicio",
                onClick = { submit() },
            )
        }
    }
}
