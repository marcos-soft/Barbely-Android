package com.barbely.app.data

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

/** Guarda las contraseñas con sal aleatoria + SHA-256 repetido (nunca en texto plano). */
object PasswordHasher {
    private const val ITERATIONS = 5000

    fun newSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return toHex(bytes)
    }

    fun hash(password: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var current = (salt + password).toByteArray(Charsets.UTF_8)
        repeat(ITERATIONS) {
            md.reset()
            current = md.digest(current)
        }
        return toHex(current)
    }

    fun matches(password: String, salt: String, expectedHash: String): Boolean =
        MessageDigest.isEqual(
            hash(password, salt).toByteArray(Charsets.UTF_8),
            expectedHash.toByteArray(Charsets.UTF_8),
        )

    private fun toHex(bytes: ByteArray): String =
        bytes.joinToString("") { String.format(Locale.US, "%02x", it) }
}
