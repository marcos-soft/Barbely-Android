package com.barbely.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import com.barbely.app.data.UserRole
import com.barbely.app.state.AppState
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Navigator
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.screens.auth.ForgotPasswordScreen
import com.barbely.app.ui.screens.auth.LoginScreen
import com.barbely.app.ui.screens.auth.RegisterScreen
import com.barbely.app.ui.screens.auth.WelcomeScreen
import com.barbely.app.ui.screens.barber.BarberAppointmentScreen
import com.barbely.app.ui.screens.barber.BarberAvailabilityScreen
import com.barbely.app.ui.screens.barber.BarberHome
import com.barbely.app.ui.screens.client.BookingBarberScreen
import com.barbely.app.ui.screens.client.BookingConfirmScreen
import com.barbely.app.ui.screens.client.BookingDateScreen
import com.barbely.app.ui.screens.client.BookingTimeScreen
import com.barbely.app.ui.screens.client.ClientAppointmentScreen
import com.barbely.app.ui.screens.client.ClientHome
import com.barbely.app.ui.screens.client.ServiceDetailScreen
import com.barbely.app.ui.screens.manager.BarberFormScreen
import com.barbely.app.ui.screens.manager.ManagerAppointmentScreen
import com.barbely.app.ui.screens.manager.ManagerHome
import com.barbely.app.ui.screens.manager.ServiceFormScreen
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BarbelyTheme

/** Raíz de la app: tema, estado compartido, botón "atrás" y enrutado de pantallas. */
@Composable
fun BarbelyApp(appState: AppState, navigator: Navigator) {
    BarbelyTheme {
        CompositionLocalProvider(
            LocalApp provides appState,
            LocalNav provides navigator,
        ) {
            val onHomeTab = navigator.current == Route.Home && navigator.homeTab != 0
            BackHandler(enabled = navigator.canPop || onHomeTab) {
                if (navigator.canPop) navigator.pop() else navigator.homeTab = 0
            }
            Box(modifier = Modifier.fillMaxSize().background(BColors.background)) {
                AppRoutes(appState, navigator)
            }
        }
    }
}

@Composable
private fun AppRoutes(app: AppState, nav: Navigator) {
    when (val route = nav.current) {
        Route.Welcome -> WelcomeScreen()
        Route.Login -> LoginScreen()
        Route.Register -> RegisterScreen()
        Route.ForgotPassword -> ForgotPasswordScreen()
        Route.Home -> HomeForRole(app)

        is Route.ServiceDetail -> ServiceDetailScreen(route.id)
        is Route.BookingBarber -> BookingBarberScreen(route.serviceId)
        is Route.BookingDate -> BookingDateScreen(route.serviceId, route.barberId)
        is Route.BookingTime -> BookingTimeScreen(route.serviceId, route.barberId, route.fecha)
        is Route.BookingConfirm ->
            BookingConfirmScreen(route.serviceId, route.barberId, route.fecha, route.hora)
        is Route.ClientAppointment -> ClientAppointmentScreen(route.id)

        is Route.BarberAppointment -> BarberAppointmentScreen(route.id)
        Route.BarberAvailability -> BarberAvailabilityScreen()

        is Route.ManagerAppointment -> ManagerAppointmentScreen(route.id)
        is Route.BarberForm -> BarberFormScreen(route.id)
        is Route.ServiceForm -> ServiceFormScreen(route.id)
    }
}

/** La pantalla principal depende del rol del usuario (cliente, barbero o gerente). */
@Composable
private fun HomeForRole(app: AppState) {
    when (app.user?.rol) {
        UserRole.CLIENTE -> ClientHome()
        UserRole.BARBERO -> BarberHome()
        UserRole.GERENTE -> ManagerHome()
        null -> WelcomeScreen()
    }
}
