package com.barbely.app.data

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

private fun flag(value: Boolean): Int = if (value) 1 else 0

// ---------- Lectura de columnas ----------

internal fun Cursor.text(col: String): String = getString(getColumnIndexOrThrow(col)) ?: ""

internal fun Cursor.textOrNull(col: String): String? {
    val index = getColumnIndexOrThrow(col)
    return if (isNull(index)) null else getString(index)
}

internal fun Cursor.integer(col: String): Int = getInt(getColumnIndexOrThrow(col))

internal fun Cursor.real(col: String): Double = getDouble(getColumnIndexOrThrow(col))

internal fun Cursor.realOrNull(col: String): Double? {
    val index = getColumnIndexOrThrow(col)
    return if (isNull(index)) null else getDouble(index)
}

internal fun Cursor.isTrue(col: String): Boolean = integer(col) != 0

/** Ejecuta un SELECT y convierte cada fila con [map]. */
internal fun <T> SQLiteDatabase.queryList(
    sql: String,
    args: Array<String> = emptyArray(),
    map: (Cursor) -> T,
): List<T> {
    val out = ArrayList<T>()
    rawQuery(sql, args).use { cursor ->
        while (cursor.moveToNext()) out.add(map(cursor))
    }
    return out
}

// ---------- Inserciones compartidas (semilla y repositorio) ----------

internal fun SQLiteDatabase.insertUserRow(
    uid: String,
    nombre: String,
    email: String,
    telefono: String?,
    rol: UserRole,
    activo: Boolean,
    password: String,
    createdAt: String,
) {
    val salt = PasswordHasher.newSalt()
    val values = ContentValues().apply {
        put("uid", uid)
        put("nombre", nombre)
        put("email", email)
        if (telefono == null) putNull("telefono") else put("telefono", telefono)
        put("rol", rol.db)
        put("activo", flag(activo))
        put("password_hash", PasswordHasher.hash(password, salt))
        put("salt", salt)
        put("created_at", createdAt)
    }
    insertOrThrow("usuarios", null, values)
}

internal fun SQLiteDatabase.insertBarberRow(
    id: String,
    nombre: String,
    descripcion: String?,
    especialidad: String,
    calificacion: Double?,
    activo: Boolean,
    email: String?,
    createdAt: String,
) {
    val values = ContentValues().apply {
        put("id", id)
        put("nombre", nombre)
        if (descripcion == null) putNull("descripcion") else put("descripcion", descripcion)
        put("especialidad", especialidad)
        if (calificacion == null) putNull("calificacion") else put("calificacion", calificacion)
        put("activo", flag(activo))
        if (email == null) putNull("email") else put("email", email)
        put("created_at", createdAt)
    }
    insertOrThrow("barberos", null, values)
}

internal fun SQLiteDatabase.insertServiceRow(
    id: String,
    nombre: String,
    descripcion: String?,
    precio: Double,
    duracion: Int,
    activo: Boolean,
    createdAt: String,
) {
    val values = ContentValues().apply {
        put("id", id)
        put("nombre", nombre)
        if (descripcion == null) putNull("descripcion") else put("descripcion", descripcion)
        put("precio", precio)
        put("duracion", duracion)
        put("activo", flag(activo))
        put("created_at", createdAt)
    }
    insertOrThrow("servicios", null, values)
}

internal fun SQLiteDatabase.insertScheduleRow(
    id: String,
    barberoId: String,
    diaSemana: Int,
    horaInicio: String,
    horaFin: String,
    activo: Boolean,
) {
    val values = ContentValues().apply {
        put("id", id)
        put("barbero_id", barberoId)
        put("dia_semana", diaSemana)
        put("hora_inicio", horaInicio)
        put("hora_fin", horaFin)
        put("activo", flag(activo))
    }
    insertOrThrow("horarios", null, values)
}

internal fun SQLiteDatabase.insertAppointmentRow(a: Appointment) {
    val values = ContentValues().apply {
        put("id", a.id)
        put("cliente_id", a.clienteId)
        if (a.clienteNombre == null) putNull("cliente_nombre") else put("cliente_nombre", a.clienteNombre)
        if (a.clienteTelefono == null) putNull("cliente_telefono") else put("cliente_telefono", a.clienteTelefono)
        put("barbero_id", a.barberoId)
        put("servicio_id", a.servicioId)
        put("fecha", a.fecha)
        put("hora_inicio", a.horaInicio)
        put("hora_fin", a.horaFin)
        put("precio", a.precio)
        put("duracion", a.duracion)
        put("estado", a.estado.db)
        put("created_at", a.createdAt)
    }
    insertOrThrow("citas", null, values)
}

internal fun boolToInt(value: Boolean): Int = flag(value)
