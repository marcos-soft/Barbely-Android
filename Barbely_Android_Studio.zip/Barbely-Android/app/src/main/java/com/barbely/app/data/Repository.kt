package com.barbely.app.data

import android.content.ContentValues
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import com.barbely.app.logic.BusyRange
import com.barbely.app.logic.minutesToTime
import com.barbely.app.logic.timeToMinutes
import java.time.Instant

private val EMAIL_REGEX = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")

/** Bloque de horario tal como lo edita la pantalla (id == null significa "nuevo"). */
data class ScheduleDraft(
    val id: String?,
    val diaSemana: Int,
    val horaInicio: String,
    val horaFin: String,
)

/**
 * Acceso a datos. Reemplaza a Firebase Authentication y Cloud Firestore.
 * Todas las operaciones son síncronas y rápidas (SQLite local); lanzan [AppException]
 * con un mensaje en español cuando algo no es válido.
 */
class Repository(private val helper: BarbelyDb) {

    private val db: SQLiteDatabase
        get() = helper.writableDatabase

    private inline fun <T> inTransaction(block: () -> T): T {
        val database = db
        database.beginTransaction()
        try {
            val result = block()
            database.setTransactionSuccessful()
            return result
        } finally {
            database.endTransaction()
        }
    }

    // ------------------------------------------------------------------
    // Usuarios y autenticación
    // ------------------------------------------------------------------

    fun getUser(uid: String): User? =
        db.queryList("SELECT * FROM usuarios WHERE uid = ?", arrayOf(uid), ::userFrom).firstOrNull()

    fun authenticate(email: String, password: String): User {
        val cleaned = email.trim()
        if (!EMAIL_REGEX.matches(cleaned)) throw AppException("El correo electrónico no es válido.")
        return db.rawQuery("SELECT * FROM usuarios WHERE email = ?", arrayOf(cleaned)).use { cursor ->
            if (!cursor.moveToFirst()) throw AppException("Correo o contraseña incorrectos.")
            val valid = PasswordHasher.matches(password, cursor.text("salt"), cursor.text("password_hash"))
            if (!valid) throw AppException("Correo o contraseña incorrectos.")
            val user = userFrom(cursor)
            if (!user.activo) throw AppException("Esta cuenta está desactivada.")
            user
        }
    }

    fun createUser(nombre: String, email: String, password: String, rol: UserRole): User {
        val cleaned = email.trim()
        if (!EMAIL_REGEX.matches(cleaned)) throw AppException("El correo electrónico no es válido.")
        if (password.length < 6) throw AppException("La contraseña debe tener al menos 6 caracteres.")
        if (emailTaken(cleaned)) throw AppException("Ese correo ya tiene una cuenta.")
        val user = User(
            uid = newId(),
            nombre = nombre.trim(),
            email = cleaned,
            telefono = null,
            rol = rol,
            activo = true,
            createdAt = Instant.now().toString(),
        )
        db.insertUserRow(user.uid, user.nombre, user.email, null, user.rol, true, password, user.createdAt)
        return user
    }

    fun updateProfile(uid: String, nombre: String, telefono: String?) {
        val values = ContentValues().apply {
            put("nombre", nombre)
            if (telefono == null) putNull("telefono") else put("telefono", telefono)
        }
        db.update("usuarios", values, "uid = ?", arrayOf(uid))
    }

    /** Sin servidor de correo no se puede enviar un enlace: el restablecimiento se hace en el dispositivo. */
    fun resetPassword(email: String, newPassword: String) {
        val cleaned = email.trim()
        if (!EMAIL_REGEX.matches(cleaned)) throw AppException("El correo electrónico no es válido.")
        if (newPassword.length < 6) throw AppException("La contraseña debe tener al menos 6 caracteres.")
        val uid = db.queryList("SELECT uid FROM usuarios WHERE email = ?", arrayOf(cleaned)) { it.text("uid") }
            .firstOrNull() ?: throw AppException("No existe una cuenta con ese correo.")
        val salt = PasswordHasher.newSalt()
        val values = ContentValues().apply {
            put("password_hash", PasswordHasher.hash(newPassword, salt))
            put("salt", salt)
        }
        db.update("usuarios", values, "uid = ?", arrayOf(uid))
    }

    /** Elimina el perfil y el historial de citas del usuario. */
    fun deleteUser(uid: String) {
        inTransaction {
            db.delete("citas", "cliente_id = ?", arrayOf(uid))
            db.delete("usuarios", "uid = ?", arrayOf(uid))
        }
    }

    private fun emailTaken(email: String, exceptUid: String? = null): Boolean {
        val count = if (exceptUid == null) {
            DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM usuarios WHERE email = ?", arrayOf(email))
        } else {
            DatabaseUtils.longForQuery(
                db,
                "SELECT COUNT(*) FROM usuarios WHERE email = ? AND uid <> ?",
                arrayOf(email, exceptUid),
            )
        }
        return count > 0
    }

    // ------------------------------------------------------------------
    // Catálogos
    // ------------------------------------------------------------------

    fun services(): List<Service> =
        db.queryList("SELECT * FROM servicios ORDER BY rowid", map = ::serviceFrom)

    fun barbers(): List<Barber> =
        db.queryList("SELECT * FROM barberos ORDER BY rowid", map = ::barberFrom)

    fun schedules(): List<Schedule> =
        db.queryList("SELECT * FROM horarios ORDER BY dia_semana, hora_inicio", map = ::scheduleFrom)

    // ------------------------------------------------------------------
    // Servicios
    // ------------------------------------------------------------------

    fun saveService(
        id: String?,
        nombre: String,
        descripcion: String?,
        precio: Double,
        duracion: Int,
        activo: Boolean,
    ) {
        if (id == null) {
            db.insertServiceRow(newId(), nombre, descripcion, precio, duracion, activo, Instant.now().toString())
            return
        }
        val values = ContentValues().apply {
            put("nombre", nombre)
            if (descripcion == null) putNull("descripcion") else put("descripcion", descripcion)
            put("precio", precio)
            put("duracion", duracion)
            put("activo", boolToInt(activo))
        }
        db.update("servicios", values, "id = ?", arrayOf(id))
    }

    fun setServiceActive(id: String, activo: Boolean) {
        val values = ContentValues().apply { put("activo", boolToInt(activo)) }
        db.update("servicios", values, "id = ?", arrayOf(id))
    }

    // ------------------------------------------------------------------
    // Barberos
    // ------------------------------------------------------------------

    /**
     * Crea (id == null) o edita un barbero. Al crear también se crea su usuario de acceso
     * (rol "barbero") con la contraseña inicial.
     */
    fun saveBarber(
        id: String?,
        nombre: String,
        especialidad: String,
        descripcion: String?,
        activo: Boolean,
        email: String,
        initialPassword: String?,
    ) {
        val cleanEmail = email.trim()
        if (id == null) {
            if (cleanEmail.isEmpty() || initialPassword == null || initialPassword.length < 6) {
                throw AppException("Para crear un barbero necesitas correo y contraseña inicial.")
            }
            if (!EMAIL_REGEX.matches(cleanEmail)) throw AppException("El correo electrónico no es válido.")
            if (emailTaken(cleanEmail)) throw AppException("Ese correo ya tiene una cuenta.")
            val now = Instant.now().toString()
            inTransaction {
                val uid = newId()
                db.insertUserRow(uid, nombre, cleanEmail, null, UserRole.BARBERO, activo, initialPassword, now)
                db.insertBarberRow(uid, nombre, descripcion, especialidad, null, activo, cleanEmail, now)
            }
            return
        }

        if (cleanEmail.isNotEmpty()) {
            if (!EMAIL_REGEX.matches(cleanEmail)) throw AppException("El correo electrónico no es válido.")
            if (emailTaken(cleanEmail, id)) throw AppException("Ese correo ya tiene una cuenta.")
        }
        inTransaction {
            val barberValues = ContentValues().apply {
                put("nombre", nombre)
                put("especialidad", especialidad)
                if (descripcion == null) putNull("descripcion") else put("descripcion", descripcion)
                put("activo", boolToInt(activo))
                if (cleanEmail.isNotEmpty()) put("email", cleanEmail)
            }
            db.update("barberos", barberValues, "id = ?", arrayOf(id))

            val userValues = ContentValues().apply {
                put("nombre", nombre)
                put("activo", boolToInt(activo))
                if (cleanEmail.isNotEmpty()) put("email", cleanEmail)
            }
            db.update("usuarios", userValues, "uid = ?", arrayOf(id))
        }
    }

    /** Un barbero inactivo no aparece al reservar y tampoco puede iniciar sesión. */
    fun setBarberActive(id: String, activo: Boolean) {
        inTransaction {
            val values = ContentValues().apply { put("activo", boolToInt(activo)) }
            db.update("barberos", values, "id = ?", arrayOf(id))
            db.update("usuarios", values, "uid = ?", arrayOf(id))
        }
    }

    /** Lo que el propio barbero puede editar de su perfil. */
    fun updateBarberProfile(id: String, especialidad: String, descripcion: String?) {
        val values = ContentValues().apply {
            put("especialidad", especialidad)
            if (descripcion == null) putNull("descripcion") else put("descripcion", descripcion)
        }
        db.update("barberos", values, "id = ?", arrayOf(id))
    }

    // ------------------------------------------------------------------
    // Horarios
    // ------------------------------------------------------------------

    /** Deja los horarios de un barbero exactamente como están en [drafts]. */
    fun replaceSchedules(barberoId: String, drafts: List<ScheduleDraft>) {
        inTransaction {
            val current = db.queryList(
                "SELECT * FROM horarios WHERE barbero_id = ?",
                arrayOf(barberoId),
                ::scheduleFrom,
            )
            val keptIds = drafts.mapNotNull { it.id }.toSet()

            for (existing in current) {
                if (existing.id !in keptIds) db.delete("horarios", "id = ?", arrayOf(existing.id))
            }
            for (draft in drafts) {
                if (draft.id == null) {
                    db.insertScheduleRow(newId(), barberoId, draft.diaSemana, draft.horaInicio, draft.horaFin, true)
                } else {
                    val original = current.firstOrNull { it.id == draft.id }
                    val changed = original != null &&
                        (original.horaInicio != draft.horaInicio || original.horaFin != draft.horaFin)
                    if (changed) {
                        val values = ContentValues().apply {
                            put("hora_inicio", draft.horaInicio)
                            put("hora_fin", draft.horaFin)
                        }
                        db.update("horarios", values, "id = ?", arrayOf(draft.id))
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Citas
    // ------------------------------------------------------------------

    /** Citas que el usuario puede ver: el gerente todas, el barbero las suyas y el cliente las suyas. */
    fun appointmentsFor(user: User): List<Appointment> = when (user.rol) {
        UserRole.GERENTE -> db.queryList(
            "SELECT * FROM citas ORDER BY fecha DESC, hora_inicio DESC",
            map = ::appointmentFrom,
        )
        UserRole.BARBERO -> db.queryList(
            "SELECT * FROM citas WHERE barbero_id = ? ORDER BY fecha DESC, hora_inicio DESC",
            arrayOf(user.uid),
            ::appointmentFrom,
        )
        UserRole.CLIENTE -> db.queryList(
            "SELECT * FROM citas WHERE cliente_id = ? ORDER BY fecha DESC, hora_inicio DESC",
            arrayOf(user.uid),
            ::appointmentFrom,
        )
    }

    /** Rangos ocupados de un barbero en una fecha (de cualquier cliente), sin contar las canceladas. */
    fun busyRanges(barberoId: String, fecha: String): List<BusyRange> =
        db.queryList(
            "SELECT hora_inicio, hora_fin FROM citas " +
                "WHERE barbero_id = ? AND fecha = ? AND estado <> 'cancelada'",
            arrayOf(barberoId, fecha),
        ) { cursor ->
            BusyRange(timeToMinutes(cursor.text("hora_inicio")), timeToMinutes(cursor.text("hora_fin")))
        }

    /**
     * Crea la cita de forma atómica: si el horario se solapa con otra cita activa del barbero
     * no se guarda nada (equivale al lote + bloqueos de Firestore).
     */
    fun createAppointment(
        cliente: User,
        barberoId: String,
        servicioId: String,
        fecha: String,
        horaInicio: String,
        duracionMinutos: Int,
        precio: Double,
    ): Appointment {
        val horaFin = minutesToTime(timeToMinutes(horaInicio) + duracionMinutos)
        val appointment = Appointment(
            id = newId(),
            clienteId = cliente.uid,
            barberoId = barberoId,
            servicioId = servicioId,
            fecha = fecha,
            horaInicio = horaInicio,
            horaFin = horaFin,
            precio = precio,
            duracion = duracionMinutos,
            estado = AppointmentStatus.PENDIENTE,
            createdAt = Instant.now().toString(),
            clienteNombre = cliente.nombre,
            clienteTelefono = cliente.telefono ?: "",
        )
        inTransaction {
            val overlapping = DatabaseUtils.longForQuery(
                db,
                "SELECT COUNT(*) FROM citas WHERE barbero_id = ? AND fecha = ? " +
                    "AND estado <> 'cancelada' AND hora_inicio < ? AND hora_fin > ?",
                arrayOf(barberoId, fecha, horaFin, horaInicio),
            )
            if (overlapping > 0) throw AppException("Ese horario ya fue ocupado. Elige otro.")
            db.insertAppointmentRow(appointment)
        }
        return appointment
    }

    fun updateAppointmentStatus(id: String, estado: AppointmentStatus) {
        val values = ContentValues().apply { put("estado", estado.db) }
        db.update("citas", values, "id = ?", arrayOf(id))
    }
}

// ----------------------------------------------------------------------
// Conversión de filas a modelos
// ----------------------------------------------------------------------

private fun userFrom(c: Cursor) = User(
    uid = c.text("uid"),
    nombre = c.text("nombre"),
    email = c.text("email"),
    telefono = c.textOrNull("telefono"),
    rol = UserRole.from(c.text("rol")),
    activo = c.isTrue("activo"),
    createdAt = c.text("created_at"),
)

private fun barberFrom(c: Cursor) = Barber(
    id = c.text("id"),
    nombre = c.text("nombre"),
    descripcion = c.textOrNull("descripcion"),
    especialidad = c.text("especialidad"),
    calificacionPromedio = c.realOrNull("calificacion"),
    activo = c.isTrue("activo"),
    createdAt = c.text("created_at"),
    email = c.textOrNull("email"),
)

private fun serviceFrom(c: Cursor) = Service(
    id = c.text("id"),
    nombre = c.text("nombre"),
    descripcion = c.textOrNull("descripcion"),
    precio = c.real("precio"),
    duracion = c.integer("duracion"),
    activo = c.isTrue("activo"),
    createdAt = c.text("created_at"),
)

private fun scheduleFrom(c: Cursor) = Schedule(
    id = c.text("id"),
    barberoId = c.text("barbero_id"),
    diaSemana = c.integer("dia_semana"),
    horaInicio = c.text("hora_inicio"),
    horaFin = c.text("hora_fin"),
    activo = c.isTrue("activo"),
)

private fun appointmentFrom(c: Cursor) = Appointment(
    id = c.text("id"),
    clienteId = c.text("cliente_id"),
    barberoId = c.text("barbero_id"),
    servicioId = c.text("servicio_id"),
    fecha = c.text("fecha"),
    horaInicio = c.text("hora_inicio"),
    horaFin = c.text("hora_fin"),
    precio = c.real("precio"),
    duracion = c.integer("duracion"),
    estado = AppointmentStatus.from(c.text("estado")),
    createdAt = c.text("created_at"),
    clienteNombre = c.textOrNull("cliente_nombre"),
    clienteTelefono = c.textOrNull("cliente_telefono"),
)
