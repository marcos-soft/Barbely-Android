# Barbely — App Android (Kotlin + Jetpack Compose)

Versión nativa de Android Studio del sistema de citas para barbería **Barbely**.
Ya **no usa Firebase, Expo ni React Native**: todo funciona sin internet con una base de datos
SQLite local dentro de la app.

## 1. Abrir el proyecto y generar el APK

1. Abre **Android Studio** → **File ▸ Open** → elige esta carpeta (`Barbely-Android`, la que contiene `settings.gradle.kts`).
2. Espera a que termine el **Gradle Sync** (la primera vez descarga Gradle y las librerías: necesita internet).
   Si pide instalar el **Android SDK 35** o aceptar licencias, acepta.
3. Para probarla: elige un emulador o tu celular (con depuración USB) y presiona **Run ▶**.
4. Para el **APK**: menú **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
   Cuando termine, pulsa **locate** en el aviso. El archivo queda en:
   `app/build/outputs/apk/debug/app-debug.apk` (se instala directo en cualquier celular Android 8.0 o superior).

Por terminal (opcional): `gradlew.bat assembleDebug` en Windows, `./gradlew assembleDebug` en Mac/Linux.
También existe `assembleRelease` (queda firmado con la llave de depuración, así que también se puede instalar).

> Si Android Studio marca error de **JDK**: *Settings ▸ Build, Execution, Deployment ▸ Build Tools ▸ Gradle ▸ Gradle JDK*
> y elige un JDK **17 o 21** (por ejemplo el `jbr-17` / `jbr-21` que trae Android Studio).
> Si sugiere "actualizar el Android Gradle Plugin", puedes ignorarlo.

## 2. Cuentas de prueba (se crean solas la primera vez que abres la app)

| Rol      | Correo                | Contraseña   |
|----------|-----------------------|--------------|
| Gerente  | gerente@barbely.com   | gerente123   |
| Barbero  | carlos@barbely.com    | barbero123   |
| Barbero  | luis@barbely.com      | barbero123   |
| Barbero  | miguel@barbely.com    | barbero123   |
| Cliente  | cliente@barbely.com   | cliente123   |

Cualquiera puede crear su propia cuenta de **cliente** desde "Crear cuenta". El gerente crea los barberos
(con su correo y contraseña inicial) desde **Gestión ▸ Nuevo barbero**.

## 3. Qué cambió respecto a la versión Expo + Firebase

| Antes (Expo / React Native)          | Ahora (Android nativo)                                        |
|--------------------------------------|---------------------------------------------------------------|
| Firebase Authentication              | Cuentas en SQLite, contraseñas con sal + SHA-256              |
| Cloud Firestore + `bloqueos`         | SQLite (usuarios, barberos, servicios, horarios, citas); una transacción impide reservar horarios que se traslapen |
| expo-router                          | Pila de navegación propia en Compose (`ui/nav/Navigator.kt`)  |
| Ionicons (fuente)                    | Los mismos 26 íconos convertidos a vectores de Android        |
| Fraunces / Manrope                   | Las mismas fuentes incluidas en `res/font`                    |
| "Olvidé mi contraseña" (correo)      | Sin servidor de correo: se restablece en el celular con correo + nueva contraseña |

Se conservan los 3 roles (cliente, barbero, gerente) y todas las pantallas del original.
Los datos son **locales a cada instalación**: no se sincronizan entre celulares, y al desinstalar la app se borran.

Mejoras menores respecto al original: las horas que ya pasaron hoy no se pueden reservar, "Tu próxima cita" muestra
la más cercana, y los bloques de horario que se empalman se rechazan.

## 4. Estructura del código (`app/src/main/java/com/barbely/app`)

- `data/` – modelos, base de datos SQLite (`BarbelyDb`, con los datos de demostración), repositorio y contraseñas.
- `logic/` – utilidades de fecha/hora y motor de disponibilidad (equivalente a `availability.ts`).
- `state/AppState.kt` – sesión y datos de la app (reemplaza al contexto de autenticación y a los listeners de Firestore).
- `ui/theme/` – colores, tipografía e íconos. `ui/components/` – botón, input, tarjetas, modal, selectores, etc.
- `ui/screens/{auth,client,barber,manager}/` – las pantallas de cada rol.
